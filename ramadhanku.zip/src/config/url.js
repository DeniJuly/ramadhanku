export default{
    api: 'http://192.168.43.92:8000/api/',
    fotoProfile: 'http://192.168.43.92:8000/img/foto-profile/',
    ilustrasi: 'http://192.168.43.92:8000/img/surat/',
    apiKota: 'https://api.banghasan.com/sholat/format/json/kota/kode/',
    apiSurat: 'https://api.banghasan.com/quran/format/json/surat',
    apiShalat: 'https://api.banghasan.com/sholat/format/json/jadwal/kota/',
    apiAllKota: 'https://api.banghasan.com/sholat/format/json/kota',
}